# Raydium CLMM — permissioned pool analysis (2026-08-09)
RESOLVED: the Permission PDA ([PERMISSION_SEED, authority]) gates ONLY pool
creation (create_permissioned_pool). No allowlist enforcement in swap paths —
trading against permissioned pools is open by design. Not a finding.
