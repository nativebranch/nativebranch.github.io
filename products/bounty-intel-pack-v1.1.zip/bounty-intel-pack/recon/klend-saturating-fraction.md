# Kamino klend 1.24 — saturating fraction collateral->liquidity (2026-08-09)
Commit c060019 added checked/saturating variants returning u64::MAX on overflow.
Both are UNUSED in the program (dead API surface); main path keeps original
panic-on-overflow. Not exploitable. Closed with evidence.
