# LIMO (Kamino Limit Orders) — First-Pass Security Review
Date: 2026-08-09 | Program: LiMoM9rMhrdYrfzUCxQppvxCSG1FcrUK9G8uLq4A1GF (mainnet)
Source: github.com/kamino-finance/limo @ 575e0e2 (Nov 2025). Audits: OtterSec (Nov 2024),
Sec3, Offside Labs, Certora (formal verification) — all findings RESOLVED in this tree.

## Attack surface (16 instructions)
- create_order / update_order / close_order_and_claim_tip / take_order
- flash_take_order_start / flash_take_order_end (atomic pair, flash_ix_lock + ix-order checks)
- initialize_global_config / initialize_vault / update_global_config / update_global_config_admin
- withdraw_host_tip
- log_user_swap_balances_start/end, assert_user_swap_balances_start/end (off-chain signal helpers)

## Architecture
- Orders: maker deposits input_mint into shared per-(config,mint) vault PDA; order tracks
  remaining_input_amount / expected_output_amount / filled_output_amount / tip_amount.
- Taker fills: pays output (>= ceil(input * expected / initial)), receives input; tips paid
  in LAMPORTS to pda_authority; host fee bps split.
- WSOL output: taker pays wSOL into per-order intermediary ATA (native account), close
  converts to SOL (native close allowed with balance), pda forwards SOL to maker.
- Permissionless/ExpressRelay: tip can be set by taker (permissionless) or via
  check_permission CPI to ExpressRelay (permission PDA must == order key — OS-KLO-ADV-00 fix).

## Checks performed (all clean)
- take_order_calcs: u128 math, ceil division, taker cannot underpay (output >= min enforced),
  over-fill tolerated (maker gains), status transitions OK.
- Accounting: remaining -= input (checked), filled += output (checked), tips tracked;
  total_tip_amount >= sum(order tips)+host maintained; close/withdraw rebaseline
  pda_authority_previous_lamports_balance.
- WSOL path: native close with balance is CORRECT SPL semantics (amount converts to lamports).
  Pre-funded intermediary accounts: initialize handles existing balance (H-01 fix, 21c397e);
  excess pre-funding accrues to pda_authority (donation only, no extraction path).
- Token-2022: transfer fees must be 0, transfer hooks unset, extension allowlist (M-01 fix OK);
  validate_token_extensions called in create/take/flash/close.
- Access control: admin-only update_global_config (has_one checks), maker-only close,
  order has_one maker/global_config/input/output mints, vault PDA seeds+authority checks,
  flash pair: args/accounts must match, no CPI from other programs (stack height check),
  no unexpected ixs (sysvar instruction scan).
- Panics: unwraps are on internal invariants (timestamps, fixed slices) — no attacker input.

## Candidate LOW/INFO (not reported; needs impact proof)
1. constraints.rs token_2022: ConfidentialTransferMint pending-balance check uses `&&`
   (`pending_balance_lo != 0 && pending_balance_hi != 0`) — `||` would match "must be zero".
   With allow_confidential_credits=false and auto_approve=false, pending can still be non-zero
   via non-confidential credits; impact on limo balance math unproven.
2. close_order_and_claim_tip: `transfer_from_vault_to_token_account(...).unwrap()` — panic
   reverts whole ix; error-message quality only.
3. update_order UpdatePermissionless stores any u8 (non-boolean) — treated as != 0 later.
4. operations.rs validate_pda_authority_balance: `balance - previous` unchecked subtraction
   (underflow-panics only if accounting invariant already broken).

## Next steps for future sessions
- Compare on-chain program hash vs this source (solana program dump + sha256) to confirm
  deployed == reviewed code before investing more.
- Focus bounty effort on NEW/un-audited Kamino modules (kvault, terminator, orbit-link,
  kbots off-chain) and fresh deployments on Immunefi/Cantina, not limo/klend.
- Revisit limo only for: express-relay permission edge cases (fees==0? expiry?), token-2022
  extension combos (TransferFeeConfig + ConfidentialTransferConfig together), and
  assert/log_user_swap_balances spoofing as an off-chain routing oracle.
