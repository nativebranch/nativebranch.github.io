# Contest Playbook — first 2 hours when a round opens (C4/Sherlock/Cantina/CodeHawks)

## Hour 0: Intelligence (15 min)
1. Read the contest page: prize pool, languages (Solana/Rust preferred — our edge),
   nSLOC, duration, rules (KYC, PoC required?).
2. Clone the code + check git log: `git log --oneline -30` — security-fix commits =
   the best bug map (raydium taught us this: "Fix allowlist" revealed a real vuln class).
3. Read the audit reports if the repo is an upgrade (audited base + delta = hunt the delta).

## Hour 1: Surface map (30 min)
4. Run the scanner: `python3 tools/solana_scan.py <repo>/programs --min-sev MED`
   → triage HIGH/MED hits first (unchecked accounts, unwraps on user input, seeds from
   user keys, unchecked arithmetic on balances).
5. Map instructions: lib.rs dispatch → handlers; note every state-mutating path and
   its access control (signers, has_one, seeds).
6. Identify the money math: share/price/fee/liquidation formulas → rounding directions.

## Hour 2: Deep dive (remaining time)
7. Focus on: (a) recently-changed code (git diff since last audit/tag),
   (b) rounding/accounting edges (can a user extract dust? can rounding favor the
   attacker?), (c) cross-instruction state (flash locks, phase transitions),
   (d) token-2022/hook/fee mints, (e) reentrancy via CPIs.
8. Write PoC ideas as tests where possible (repo test env; pure-Rust math fuzz in
   Python like the kvault simulation).
9. Submit early, submit often — even MED findings pay; duplicate submissions are the
   main waste, so prioritize obscure-but-real paths.

## Tooling
- tools/solana_scan.py — static pattern scanner (grep-based, fast)
- Python fraction simulation — replicate share math, fuzz for extraction
- cargo test on repo (stable Rust usually enough for lib tests)
- Obscura/HTTP — for docs/audits/recon pages
