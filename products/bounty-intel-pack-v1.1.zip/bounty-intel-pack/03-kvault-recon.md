# Kvault (Kamino Lending Vault) — First-Pass Recon
Date: 2026-08-09 | Mainnet: KvauGMspG5k6rtzrqqn7WNn3oZdyKqLKwK2XWQ8FLjd
Source: github.com/kamino-finance/kvault @ 1d146d7 "release 2.2.2" (2026-07-08 — ONE MONTH OLD)

## Why this target
- Actively developed (2.2.2 landed Jul 8 2026; +1602/-878 lines vs 2.2.1).
- Vaults pool user deposits into KLend reserves per admin allocations; shares math +
  fees + invest/divest CPIs = classic bug surface. Fresh code = best bug odds on Immunefi.

## Architecture
- VaultState (zero_copy): token_available, shares_issued, prev_aum_sf, pending_fees_sf,
  performance/management fee bps, allocations[25] (target weight, ctoken caps),
  withdrawal penalty (lamports + bps), deposit cap, reward info, first-loss farm.
- AUM = token_available + invested_total - pending_fees (Fraction U68F60 from klend).
- Ixs: init_vault, deposit, withdraw, withdraw_pending_fees, give_up_pending_fees,
  invest (with holdings snapshot), redeem_in_kind, withdraw_rewards, topup_rewards,
  update_reserve_allocation, add_update_whitelisted_reserve, admin/config updates.

## Security posture (strong)
- deposit: post-checks on ATA/vault balances + shares_issued consistency; shares_to_mint
  from AUM; user pays crank funds (num_reserve * fee_per_reserve).
- withdraw: total_for_user = aum * shares/supply (floor); withdrawal penalty (max of
  lamports floor, bps ceil); available first, then disinvest from chosen reserve with
  ctoken ceil / liquidity floor + rounding error handling; shares_to_burn ceil, min with
  requested; post_transfer_withdraw_balance_checks enforces exact balance deltas.
- invest 2.2.2: HoldingsBuffer snapshot BEFORE CPI, sync_reserve AFTER, AUM before/after
  comparison + post_transfer_invest_checks.
- redeem_in_kind: post checks on ctokens/shares/aum decrease <= liquidity value.
- Token-2022 supported; whitelist gates for allocations/invest.

## Hotspots to stress-test next session (in priority order)
1. withdraw rounding: `liquidity_rounding_error` logic (only when frac > frac) and
   `shares_to_burn` ceil vs `compute_user_total_received_on_withdraw` floor — dust
   extraction across many small withdraws? (penalty bps/lamports may offset).
2. charge_fees: mgmt on prev_aum even during losses; perf only on gains; pending_fees
   can exceed AUM? `new_fees = (mgmt+perf).min(new_aum)` caps; prev_aum updated to
   new_aum - fees; check first-deposit-vs-fee race (last_fee_charge_timestamp==0 skip).
3. invest_with_holdings_snapshot: other reserves use STALE prices while target reserve
   refreshed — AUM-before/after mismatch DoS or pass-with-wrong-value? Read the full
   function (vault_operations.rs:538-706).
4. ctoken_cap (new file): cap logic on invest — bypass via multiple reserves?
5. redeem_in_kind: user receives reserve ctokens directly — exchange-rate rounding,
   partial redemption, interplay with ctoken caps.
6. Handler update_reserve_allocation changes (2.2.2): target weights/caps validation
   (sum weights <= 100%? unallocated_weight accounting).
7. give_up_pending_fees / withdraw_pending_fees: fee accounting vs AUM.

## Known audits
Check kamino-finance/audits repo for kvault reports (2.0.x era). The 2.2.x delta is
likely NOT fully audited — that's the edge.

## Tools for next session
- Build with anchor (needs solana toolchain: `cargo install --locked anchor-cli` or
  use agave; heavy). Alternative: static analysis + litesvm tests in libs/kvault-interface
  (tests exist for deposit/invest/redeem/withdraw — extend with adversarial cases).


## Final verdict (session 9, 2026-08-09)
FULL pass complete: deposit, withdraw, invest (+snapshot), redeem_in_kind, charge_fees,
refresh_rewards/topup/withdraw, share math (simulated in Python), ctoken caps,
allocation refresh. All rounding vault-favorable; accounting token-consistent;
post-transfer invariant checks on every path; admin-gated configs. NO reportable
finding. Kvault 2.2.2 is well-hardened — deprioritize unless new release lands.
