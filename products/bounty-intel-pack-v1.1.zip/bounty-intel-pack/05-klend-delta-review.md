

## klend 1.24.0 delta review (2026-08-09, session 17) — NEW FEATURE MAP
Release 67bd6dc (Jul 30 2026) vs 1.23.0 (3759217). Diff: 218KB src changes.
NEW/SECURITY-RELEVANT:
1. BORROW ORDERS (multi-order): obligation.borrow_order → indexed orders
   (get_borrow_order/get_borrow_order_mut, order_idx u8). fill_borrow_order v2
   validates per-order: reserve mint == order.debt_liquidity_mint AND destination ==
   order.filled_debt_destination (check_accounts_match_order). v1 = v2 with idx 0.
   REVIEW NEXT: open/enqueue/cancel/rollover paths + fill_amount bounds + expiry
   clearing (clear_expired_borrow_orders_for_ownership_transfer).
2. handler_calculate_ctoken_exchange_rate (NEW, 77 lines) + ctoken_exchange_rate.rs
   interface + tests: admin oracle for exchange rate? CHECK access control + bounds.
3. Ownership transfer: added ix_utils::check_no_advance_nonce_ix_within_tx on
   approve — anti-atomicity guard; abort/accept refactored (xmsg only).
4. saturating_fraction_collateral_to_liquidity (#69, Jun 26): returns u64::MAX on
   overflow; NOT used in klend; in kvault used for ctoken-cap conversion — verified
   bounded by token cap (min()), NOT exploitable. (Analyzed + closed.)
5. enqueue_to_withdraw / withdraw tickets, clone_reserve_config, init_farms_for_reserve
   changes — lower priority.
NEXT SESSION: deep-dive borrow-order subsystem (programs/klend/src/state/obligation.rs
orders + handlers) with litesvm tests; check exchange-rate handler access control.


## Borrow-order subsystem review (2026-08-09, session 18) — RESULT: clean
Reviewed: handler_set_borrow_order (v1/v2), handler_fill_borrow_order (v1/v2),
borrow_order_operations.rs (set/fill/rollover/validations), obligation.rs order access.
- set: config validated (max_rate>0, remaining>0, fillable_until>=now, min value);
  race-guard via min_expected_current_remaining_debt_amount; no-op cancel path OK.
- fill: rate<=order max (reserve CONFIG max), term>=min (reserve term + maturity
  remaining), time<=fillable_until, amount<=remaining (BorrowSize::AtMost at handler),
  min-fill-value + remaining-value checks; borrow+order update atomic (revert on any
  error); unchecked sub in fill_borrow_order is SAFE because handler bounds amount.
- rollover: propagate_rollover_config_to_borrow checks market flag + compatibility
  with pre-existing borrow slot.
- NOTE for future: verify reserve rate-setter enforces current_rate <= config
  max_borrow_rate_bps (if rate can exceed config max, order-max check is weakened).
