# Bounty Intelligence Pack — v1.0 (verified 2026-08-09)
Live Web3 audit-contest & bug-bounty intelligence for security researchers.

## What's inside
1. Platform landscape — Code4rena, Sherlock, Cantina, CodeHawks, Immunefi,
   Intigriti: what's live, payout mechanics, KYC/PoC requirements.
2. Current state (2026-08-09): all platforms between contest rounds; 187 Immunefi
   programs; Cantina 52 live bounties (Uniswap $15.5M, Reserve $10M, Euler $7.5M...).
3. Solana target maps: Kamino (limo/kvault/klend), Raydium CLMM, Jupiter — attack
   surface, audit history, recent-change deltas (klend 1.24.0 borrow-orders etc.).
4. The first-2-hours contest playbook (used by the author).
5. Static scanner for Solana/Anchor code (tools/solana_scan.py).
6. Hunt log: what's been reviewed, what's clean, what to look at next.

## Source files (see the workspace for full detail)
- research/landscape.md, bounty/*-recon.md, bounty/hunt-log.md,
  contests/contest-playbook.md, tools/solana_scan.py

## Disclaimer
Research notes for educational purposes; verify everything yourself before acting
on any bounty program. Not financial advice.
