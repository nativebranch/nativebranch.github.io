# Raydium CLMM — Recon Memo (2026-08-09)
Program: CAMM... (raydium-clmm) | Immunefi: max $505k, critical min $50k, high $5-40k,
medium flat $5k | 74 assets | live since 2023, last updated 2026-07-09
Source: github.com/raydium-io/raydium-clmm @ 51fdba2 (Jul 31 2026) — clone in ./raydium-clmm

## Why hot
- Recent heavy feature work: LIMIT ORDERS + DYNAMIC FEES (Jun-Jul 2026), PERMISSIONED
  POOLS (Jul 2026, #194), bitmap perf refactor. Multiple security fixes landed Jun-Jul:
  - 51fdba2 (Jul 31) "Fix allowlist": REMOVED a FORGEABLE Superstate-mint bypass
    (is_superstate_token skipped token-2022 extension validation for any mint whose
    freeze_authority = hardcoded Superstate ID — anyone could create such a mint →
    pools with hook/fee-enabled mints). Also hardened swap user-account constraints
    (mint+authority) and added frozen-account checks to open_position/v2/t22 and
    open_limit_order. Vault accounts now always get ImmutableOwner.
  - 5d3e19d as_u64 panic in limit-order conversion (swap)
  - fcad161 exact-input dust infinite loop + bitmap-boundary misclassification
  - b4a362e reward emission overflow → saturate instead of panic
  - ed289d6/f1ec7dc/6dcdd56/5e13240/cf5db98 limit-order safety + rounding fixes
- Already-fixed classes often have sibling bugs (fixes were narrow).

## Verified sound (this session)
- swap.rs SwapSingle: input_token_account must be payer-owned with input mint;
  output_token_account must be output mint (authority intentionally NOT required —
  output goes to any account of the mint). input_vault/output_vault ARE checked
  against pool_state.token_vault_0/1 (InvalidInputPoolVault) — no fake-vault drain.
- is_supported_mint (token-2022): allowlist = TransferFeeConfig, MetadataPointer,
  TokenMetadata, InterestBearingConfig, ScaledUiAmount; everything else rejected.
  Called in create_pool, create_customizable_pool, create_permissioned_pool,
  initialize_reward. mint_associated_is_initialized shortcut is ADMIN-GATED
  (SupportMintAssociated PDA in remaining_accounts) — not attacker-forgeable.
- create_permissioned_pool: require_gt!(seed_index, 0) prevents collision with
  classic pool seeds; permission PDA = [PERMISSION_SEED, payer] — but note
  pool_creator is an UNCHECKED account: verify the allowlist logic uses payer vs
  pool_creator correctly (who ends up as the pool's creator/authority?).
- settle_limit_order: signer = owner OR hardcoded limit_order_admin (centralization
  note, by design); output_vault checked against pool vaults; transfer uses pool
  seeds. amount_out from settle_filled_order(tick_state).

## HOTSPOTS for next session (limit-order fill math — the money area)
1. programs/amm/src/states/limit_order.rs (98KB!) — settle_filled_order,
   get_unfilled_amount, fill accounting; check ROUNDING DIRECTIONS: can a swapper
   fill a limit order at a better price than the order's limit (rounding in
   swapper's favor)? Can settle pay out MORE than filled (rounding up in settle)?
2. Swap integration in tick_array.rs / swap.rs: when a swap crosses a limit-order
   tick, how is the fill amount computed vs the order's remaining amount; the
   "dust" fixes (6dcdd56, fcad161) suggest exact-input edge cases — look for
   remaining dust that is NOT consumed but still marked filled, or vice versa.
3. increase/decrease_limit_order: partial fills + adjustments; check that
   decreasing an order can't withdraw already-filled amounts or create
   underflow/overfill; permissionless vs owner constraints.
4. open_limit_order: new output_token_account frozen check; input frozen check;
   zero_for_one vault constraints — verify the tick/tick_array constraints
   (tick must belong to pool, within bounds, correct spacing) and that amount>0,
   no same-mint pool, price limit checks (can an order be placed beyond
   MAX_TICK_SPACING / at a price that can never fill but blocks ticks?).
5. Permissioned pools: who can swap against them (allowlist enforcement in swap?);
   pool_creator vs payer; seed_index collision across configs.
6. Dynamic fee config (states/dynamic_fee_config.rs + swap_math): fee computation
   with volume — rounding/extremes (fee = 0? fee = 100%?).

## Setup for real testing
- Build: cargo build-sbf (needs solana toolchain) — or use the repo's existing
  tests (programs/amm has test dirs? check). Anchor not required (plain Rust).
- The repo has unit tests for tick math/swap math (libraries/*) — extend with
  adversarial limit-order cases rather than full localnet.

## Bounty program notes
- PoC required, KYC required. Primacy of Rules except direct theft = Primacy of
  Impact. Critical = 10% of funds at risk, min $50k, max $505k. Testing on local
  forks only. Report via Immunefi (account needed — user action).


## Session 6 deep-dive results (2026-08-09, second pass)
- Built the full test suite with stable Rust (no solana toolchain needed): 200/200 pass.
- Reviewed match_limit_order_with_sqrt_price (swap-side fill): units consistent
  (total_unfilled = maker-input units = matched_output); base-input/base-output + fee
  variants all use safe rounding (floor on output-to-maker, ceil on input-from-swapper);
  FIFO consumption (part_filled first), phase++ on orders_amount consumption,
  require_gte! guards on orders_amount.
- settle_filled_order: diff-based payout with -1 dust; full-fill branch recovers dust;
  filled_amount always updated; per-order payout <= share (floor ratios). Sound.
- increase/decrease: phase-gated; decrease settles first, caps at
  part_filled_orders_remaining (prevents vault insolvency), resets settle_base/ratio
  correctly, slippage check (amount_min) on return. Tick deinit + bitmap flip handled.
- close_limit_order: closes ONLY the order account when unfilled==0 — an unsettled
  fully-filled order closed early LOCKS the un-settled output in the vault (maker
  self-harm; admin can also do it — centralization by design, not reportable).
- Verified overflow-checks=true in release profile (no silent wrapping).
- CONCLUSION: limit-order subsystem is mature + heavily tested; no reportable finding
  this pass. Next best angles (lower probability): permissioned-pool allowlist
  enforcement in swaps (only open_limit_order got the allowlist/frozen checks — check
  swap paths against permissioned pools), dynamic-fee edge cases, oracle/observation
  manipulation, and the bitmap-extension perf refactor (695968c) for boundary bugs.
- Toolchain note: `cargo test -p raydium-clmm --lib` works with plain stable Rust;
  full program build needs solana platform tools (dangling /tmp/solana-release link —
  would need reinstall, ~2-3GB, RAM is tight: 14GB total, mostly used).
