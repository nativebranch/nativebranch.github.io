# $10k Mission — Landscape (2026-08-09)

## Audit contests (schedule-gated)
- Code4rena: NOTHING active/upcoming right now (K2 Stellar Rust $135k ended May 27; report expected Aug 1). Solana/Rust contests recur (Jupiter Lend $107k Feb, LayerZero-Stellar $101k Apr, Solana Fdn $203.5k history).
- CodeHawks: BattleChain Confidence Pools (7.25 ETH) in Appeals Review (ended Jul 16). No public active.
- Sherlock: 1 active (undisclosed), most in judging. Ethereum Fusaka $2M & MakerDAO $1.39M finished.
- Cantina: 1 competition ended (Morpho Midnight $400k, ended Jun 12). 52 LIVE bounties.
- Tracking: audits.trenchscreener.ai/?filter=upcoming (stale), need own monitor.

## Live bounties (always on)
- Cantina: Uniswap $15.5M, Reserve $10M, Euler $7.5M, Polymarket $5M, Coinbase $5M, Morpho $2.5M, Pendle $2M, Ondo Perps $1.5M, dYdX $1M, Paxos $1M (mostly EVM).
- Immunefi: Kamino (Solana largest, $1.5M critical), Jupiter, Drift, Jito, Pyth, Marinade.

## Technical writing (paying, verified Mar 2026)
- Airbyte $300-500 (+$200 bonus) — data pipelines, NO AI content — airbyte.com/write-for-the-community
- Vultr up to $800 — cloud — creators.vultrdevrel.com/signup
- Retool $500-1000 — content@retool.com
- Stack Overflow $500 — stackoverflow.blog
- Draft.dev $315-578 — draft.dev/write
- Civo $200-500 — civo.com/write-for-us
- Kestra $300+ — kestra.io/write-for-us
- Appsmith $200-400 — content@appsmith.com
- Semaphore up to $500 — semaphore.io
- MetalBear $300 — metalbear.co/writers-program
- Simple Talk $350 — red-gate.com/simple-talk/write-for-us
- Every Developer $300+ — everydeveloper.com/join
- Literally $250-800 — literally.homerun.co/technical-writer/en

## Freelance
- Contra: 0% commission, per-payment fee $2-29. Profile + proposals needed.

## Plan
A. Articles (fast cash): 3 complete + 5 pitches.
B. Bounty: pick 1 Solana-Rust target, recon + review, produce findings.
C. Contest monitor: cron/heartbeat on trackers.
D. Freelance: Contra profile copy + proposals.
