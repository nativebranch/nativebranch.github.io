#!/usr/bin/env python3
"""solana_scan.py — fast static pattern scanner for Solana/Anchor Rust programs.
Usage: python3 solana_scan.py <repo_dir> [--context N] [--json]
Finds high-signal patterns for manual review: unchecked math, unwraps/panics,
weak account constraints, unsafe casts, suspicious token ops.
"""
import os, re, sys, json, argparse

PATTERNS = [
    # (name, regex, severity, hint)
    ("unchecked_sub", r'[a-z_0-9]+\.\s*[a-z_0-9]+ *- *[a-z_0-9]+\b', "MED",
     "possible u64 underflow — prefer checked_sub/saturating_sub"),
    ("unwrap", r'\.unwrap\(\)', "MED",
     "panic on error — check if attacker-controlled input reaches it"),
    ("expect", r'\.expect\("', "LOW", "panic with message — verify invariant"),
    ("panic", r'panic!\("', "LOW", "explicit panic"),
    ("as_u64_cast", r'as u64', "LOW", "cast — check truncation on u128/u64"),
    ("as_u128_cast", r'as u128', "LOW", "cast — check sign/truncation"),
    ("unchecked_add", r'\.checked_add\(', "INFO", "checked add — verify guard"),
    ("no_signer_check", r'UncheckedAccount', "MED",
     "unchecked account — verify it's validated in handler"),
    ("token_transfer", r'transfer_checked|transfer\(', "INFO",
     "token transfer — verify amounts + authority"),
    ("cpi_invoke", r'invoke(_signed)?\(', "INFO", "CPI — check seed/signer usage"),
    ("lamports", r'lamports\(\)', "INFO", "lamport math — check rent/balance handling"),
    ("close_account", r'close_account|close\(', "MED",
     "account close — verify balance zero + destination"),
    ("seed_from_user", r'seeds\s*=\s*\[[^\]]*payer|seeds\s*=\s*\[[^\]]*user', "HIGH",
     "PDA seeds from user-controlled key — verify no collision/authority issue"),
    ("clock_unchecked", r'Clock::get\(\)\?\.unix_timestamp\s+as u64', "LOW",
     "timestamp cast — negative timestamps wrap"),
    ("try_from_unwrap", r'try_into\(\)\.unwrap\(\)|try_from\(.*\)\.unwrap\(\)', "MED",
     "panic on conversion — check input bounds"),
    ("div_by_zero_risk", r'\.checked_div\(|/ *[a-z_]+', "LOW",
     "division — check zero divisor guards"),
    ("realloc", r'realloc|try_realloc', "MED", "realloc — verify rent/lamport handling"),
]

def scan(path, context=2):
    hits = []
    for root, dirs, files in os.walk(path):
        dirs[:] = [d for d in dirs if d not in ('.git','node_modules','target','.anchor','.github','tests','test')]
        for f in files:
            if not f.endswith('.rs'): continue
            p = os.path.join(root, f)
            try:
                lines = open(p, encoding='utf-8', errors='replace').read().splitlines()
            except Exception:
                continue
            for i, line in enumerate(lines):
                for name, pat, sev, hint in PATTERNS:
                    if re.search(pat, line):
                        ctx_lines = lines[max(0,i-context):i+context+1]
                        hits.append({
                            'file': os.path.relpath(p, path), 'line': i+1,
                            'pattern': name, 'severity': sev, 'hint': hint,
                            'code': line.strip()[:160],
                            'ctx': [c.strip()[:120] for c in ctx_lines],
                        })
    return hits

if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('path')
    ap.add_argument('--context', type=int, default=2)
    ap.add_argument('--json', action='store_true')
    ap.add_argument('--min-sev', default='LOW', choices=['HIGH','MED','LOW','INFO'])
    a = ap.parse_args()
    hits = scan(a.path, a.context)
    order = {'HIGH':0,'MED':1,'LOW':2,'INFO':3}
    hits.sort(key=lambda h: (order[h['severity']], h['file'], h['line']))
    if a.json:
        print(json.dumps(hits, indent=1))
    else:
        sev_min = order[a.min_sev]
        counts = {}
        for h in hits:
            counts[h['severity']] = counts.get(h['severity'],0)+1
        print(f"scan: {len(hits)} hits | {counts}")
        for h in hits:
            if order[h['severity']] > sev_min: continue
            print(f"\n[{h['severity']}] {h['pattern']} @ {h['file']}:{h['line']}")
            print(f"  {h['code']}")
            print(f"  hint: {h['hint']}")
