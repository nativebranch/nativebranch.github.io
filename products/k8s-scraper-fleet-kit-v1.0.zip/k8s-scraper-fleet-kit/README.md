# K8s Scraper Fleet Kit — queue, workers, autoscale, done

A copy-paste foundation for a production web-scraping fleet on Kubernetes
(works on any K8s: Civo K3s, EKS, GKE, k3d). Verified patterns from production.

## What's inside
- worker/worker.py — Redis queue → headless browser (Playwright) → object storage
- worker/Dockerfile + requirements.txt
- manifests/ — Deployment, HPA (queue-depth metric), CronJob scheduler, Redis, Secrets
- docs/ — the full fleet tutorial (Civo + Vultr variants)

## Deploy (10 minutes)
```bash
kubectl apply -f manifests/redis.yaml
kubectl apply -f manifests/secret.example.yaml   # edit with your keys first
docker build -t your-registry/scraper-worker:latest worker/ && docker push ...
kubectl apply -f manifests/worker.yaml
kubectl apply -f manifests/scheduler.yaml
kubectl apply -f manifests/hpa.yaml
```

## The patterns that matter
- Workers are stateless; the queue is the only state
- Memory budget per Pod: 1-2 GiB, 2 tabs max (browsers OOM otherwise)
- Scale on queue depth, not CPU (browsers are bursty)
- Empty runs fail loudly (scheduler checks item counts)
