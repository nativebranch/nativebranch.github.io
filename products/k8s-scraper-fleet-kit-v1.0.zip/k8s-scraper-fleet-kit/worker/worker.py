#!/usr/bin/env python3
"""Worker: pop URL from Redis queue, render with headless browser, store to S3."""
import json, os, uuid, redis, boto3
from playwright.sync_api import sync_playwright

r = redis.Redis(host=os.environ.get("REDIS_HOST", "redis"), port=6379, decode_responses=True)
s3 = boto3.client("s3", endpoint_url=os.environ.get("S3_ENDPOINT"),
                  aws_access_key_id=os.environ.get("S3_KEY"),
                  aws_secret_access_key=os.environ.get("S3_SECRET"))
BUCKET = os.environ.get("S3_BUCKET", "scraped")

while True:
    job = r.blpop("scrape:queue", timeout=5)
    if not job:
        continue
    url = json.loads(job[1])["url"]
    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            page.goto(url, timeout=30000, wait_until="networkidle")
            html = page.content()
            browser.close()
        key = f"pages/{uuid.uuid4().hex}.html"
        s3.put_object(Bucket=BUCKET, Key=key, Body=html)
        r.rpush("scrape:done", json.dumps({"url": url, "key": key}))
    except Exception as e:
        r.rpush("scrape:failed", json.dumps({"url": url, "error": str(e)}))
