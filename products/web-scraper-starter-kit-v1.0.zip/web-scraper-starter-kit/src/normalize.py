#!/usr/bin/env python3
"""normalize.py — parse a scraped HTML file into JSONL records.
Example: python normalize.py page.html --selector 'tr.athing' \
    --fields 'rank:.rank|title:td.title span.titleline a|url:td.title span.titleline a@href'
"""
import argparse, json, pathlib, datetime
from bs4 import BeautifulSoup

def extract(node, spec: str):
    """spec: 'tag' | 'tag@attr' | '.class' | '#id' or CSS selector, optional @attr."""
    sel, _, attr = spec.partition("@")
    el = node.select_one(sel) if sel else node
    if el is None:
        return None
    return el.get(attr) if attr else el.get_text(strip=True)

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("html_file")
    ap.add_argument("--selector", required=True, help="CSS selector for record rows")
    ap.add_argument("--fields", required=True, help="name:selector[@attr] comma-separated")
    ap.add_argument("--out", default="items.jsonl")
    ap.add_argument("--source", default="")
    args = ap.parse_args()

    soup = BeautifulSoup(pathlib.Path(args.html_file).read_text(), "lxml")
    # fields are pipe-separated (CSS selectors may contain commas)
    raw_fields = args.fields.split("|") if "|" in args.fields else args.fields.split(",")
    fields = [f.split(":", 1) for f in raw_fields if ":" in f]
    rows = []
    for row in soup.select(args.selector):
        rec = {"scraped_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "source": args.source}
        for name, spec in fields:
            rec[name] = extract(row, spec)
        rows.append(rec)
    with open(args.out, "w") as f:
        for r in rows:
            f.write(json.dumps(r) + "\n")
    print(f"parsed {len(rows)} records -> {args.out}")

if __name__ == "__main__":
    main()
