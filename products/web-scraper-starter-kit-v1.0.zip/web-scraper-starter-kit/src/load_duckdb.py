#!/usr/bin/env python3
"""load_duckdb.py — load JSONL into DuckDB (or Postgres via Airbyte in compose).
Usage: python load_duckdb.py items.jsonl --db warehouse.duckdb --table hn_items
"""
import argparse, duckdb

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("jsonl")
    ap.add_argument("--db", default="warehouse.duckdb")
    ap.add_argument("--table", default="items")
    args = ap.parse_args()

    con = duckdb.connect(args.db)
    con.execute(f"CREATE OR REPLACE TABLE {args.table} AS SELECT * FROM read_json_auto('{args.jsonl}')")
    n = con.execute(f"SELECT count(*) FROM {args.table}").fetchone()[0]
    print(f"loaded {n} rows into {args.db}.{args.table}")
    con.close()

if __name__ == "__main__":
    main()
