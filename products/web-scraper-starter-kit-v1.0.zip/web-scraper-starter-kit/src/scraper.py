#!/usr/bin/env python3
"""scraper.py — render a page with a headless browser and save the HTML.
Usage: python scraper.py URL [--out out.html] [--retries 3] [--delay 2]
Uses the `obscura` headless browser if available, else Playwright.
"""
import argparse, subprocess, sys, time, pathlib

def fetch_obscura(url: str, timeout: int = 60) -> str:
    r = subprocess.run(
        ["obscura", "fetch", "--dump", "html", "--timeout", str(timeout), "--stealth", url],
        capture_output=True, text=True, timeout=timeout + 40,
    )
    if r.returncode != 0:
        raise RuntimeError(f"obscura failed: {r.stderr[-300:]}")
    return r.stdout

def fetch_playwright(url: str, timeout: int = 60) -> str:
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto(url, timeout=timeout * 1000, wait_until="networkidle")
        html = page.content()
        browser.close()
    return html

def fetch(url: str, timeout: int = 60) -> str:
    try:
        return fetch_obscura(url, timeout)
    except FileNotFoundError:
        return fetch_playwright(url, timeout)

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("url")
    ap.add_argument("--out", default="page.html")
    ap.add_argument("--retries", type=int, default=3)
    ap.add_argument("--delay", type=float, default=2.0, help="seconds between retries")
    args = ap.parse_args()

    for attempt in range(1, args.retries + 1):
        try:
            html = fetch(args.url)
            pathlib.Path(args.out).write_text(html)
            print(f"OK: {len(html)} bytes -> {args.out}")
            return
        except Exception as e:
            print(f"attempt {attempt}/{args.retries} failed: {e}", file=sys.stderr)
            if attempt < args.retries:
                time.sleep(args.delay)
    sys.exit(1)

if __name__ == "__main__":
    main()
