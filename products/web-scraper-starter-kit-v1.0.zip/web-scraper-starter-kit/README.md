# Web Scraper Starter Kit — headless browser → JSONL → warehouse

A copy-paste foundation for production web scraping, verified end-to-end on
2026-08-09 (Hacker News demo: 30 records scraped → JSONL → DuckDB).

## What's inside
- `src/scraper.py` — render any page (JS included) with a headless browser,
  retries + polite delays. Uses `obscura` (lightweight, no server) or Playwright.
- `src/normalize.py` — turn HTML into clean JSONL records (schema drift friendly).
- `src/load_duckdb.py` — land JSONL in DuckDB in one command.
- `docker-compose.yml` — Airbyte OSS + Postgres for scheduled, incremental ELT
  (the "production" path from the accompanying article).

## Quick start (5 minutes)
```bash
pip install -r requirements.txt        # requests, bs4, lxml, duckdb, playwright
python src/scraper.py https://news.ycombinator.com/ --out hn.html
python src/normalize.py hn.html \
  --selector 'tr.athing' \
  --fields 'rank:.rank|title:td.title span.titleline a|url:td.title span.titleline a@href' \
  --source news.ycombinator.com --out hn_items.jsonl
python src/load_duckdb.py hn_items.jsonl --table hn_items
```

## Go further
- Schedule: cron / systemd timer / Airbyte scheduled syncs (compose included).
- Scale: queue + stateless workers (see the Civo/Vultr articles in docs/).
- Alert on empty scrapes: any orchestrator (Kestra flow included in docs/).

## Requirements
Python 3.10+, a headless browser (obscura OR playwright). Optional: Docker for Airbyte.
