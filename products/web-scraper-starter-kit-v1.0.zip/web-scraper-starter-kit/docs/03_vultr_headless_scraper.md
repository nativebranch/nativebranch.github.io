# Zero-to-scraper: deploy a headless browser scraping service on Vultr

*Tutorial for Vultr Docs — 30 minutes, real products, working code. All commands verified
against Vultr Compute + Object Storage workflows.*

## Why a headless browser?

Modern websites render their content with JavaScript. `curl` gets you an empty shell;
a headless browser executes the page and gives you the rendered DOM — the same HTML a
real user sees. That capability is the difference between scraping that works on 20% of
the web and scraping that works on 95% of it.

In this tutorial you'll deploy a production-shaped scraping service on Vultr:

- **Vultr Compute** — two instances running a containerized worker behind a load balancer
- **Vultr Object Storage** — S3-compatible storage for raw results
- A scheduler that enqueues URLs, and a worker that renders pages and stores them

Everything is open source, runs on the cheapest instance tier, and scales horizontally.

## Step 1 — Provision the infrastructure

Create the following from the Vultr console (or the API):

1. **Compute instance** (regular cloud compute, 1 vCPU / 1 GB is enough to start) with
   Ubuntu 24.04 and Docker installed. This will be your *builder* — we'll bake the worker
   image here and push it to a registry.
2. **Second Compute instance** — your worker host. (For production, use a load balancer
   in front and scale to a cluster; for this tutorial one worker host is fine.)
3. **Object Storage bucket** — create a bucket named `scraped-pages` and generate an
   access key with read/write permission on it.

## Step 2 — The worker

The worker is a small Python service: pop a URL from a queue, render it in a headless
browser (Playwright's Chromium), upload the HTML to object storage, and report the
result. Keep it stateless — the queue and object storage are the only state.

```python
# worker.py
import json, os, uuid
import boto3
from playwright.sync_api import sync_playwright
import redis

r = redis.Redis(host=os.environ["REDIS_HOST"], port=6379, decode_responses=True)
s3 = boto3.client(
    "s3",
    endpoint_url=os.environ["S3_ENDPOINT"],       # your Vultr Object Storage endpoint
    aws_access_key_id=os.environ["S3_KEY"],
    aws_secret_access_key=os.environ["S3_SECRET"],
)

while True:
    job = r.blpop("scrape:queue", timeout=5)
    if not job:
        continue
    url = json.loads(job[1])["url"]
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto(url, timeout=30_000, wait_until="networkidle")
        html = page.content()
        browser.close()
    key = f"pages/{uuid.uuid4().hex}.html"
    s3.put_object(Bucket="scraped-pages", Key=key, Body=html)
    r.rpush("scrape:done", json.dumps({"url": url, "key": key}))
```

The Dockerfile is deliberately boring:

```dockerfile
FROM mcr.microsoft.com/playwright/python:v1.49.0-noble
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY worker.py .
CMD ["python", "worker.py"]
```

Build and push:

```bash
docker build -t your-registry/scraper-worker:latest .
docker push your-registry/scraper-worker:latest
```

## Step 3 — Run it on Vultr

On the worker host:

```bash
docker run -d --name worker --restart unless-stopped \
  -e REDIS_HOST=... -e S3_ENDPOINT=... -e S3_KEY=... -e S3_SECRET=... \
  your-registry/scraper-worker:latest
```

For Redis, spin up a small Vultr Compute instance with Docker and run `redis-server`
(one line), or use a managed Redis if you prefer. Enqueue a test URL:

```bash
redis-cli -h $REDIS_HOST rpush scrape:queue '{"url": "https://example.com"}'
```

Watch the logs — within seconds the page is rendered and uploaded:

```bash
docker logs -f worker
```

Then confirm the object landed in your bucket via the Vultr Object Storage UI, or:

```bash
aws --endpoint-url $S3_ENDPOINT s3 ls s3://scraped-pages/pages/
```

## Step 4 — Make it a service

Three upgrades turn the prototype into something you can run for months:

1. **Schedule it.** A tiny cron on a third instance (or the same one) enqueues your URL
   list every N minutes. The workers stay stateless; scaling = `docker run -d` again.
2. **Retry with backoff.** On failure, re-enqueue the job with a `retries` counter and
   an exponential delay. Transient network errors are normal; silent data loss is not.
3. **Watch your numbers.** Log queue depth, per-page render time, and bytes stored.
   A sudden drop to zero pages per run is your early-warning that the target site
   changed its markup.

## Costs

At the smallest tiers: one 1 vCPU/1 GB instance for the worker (~$6/mo), a tiny Redis
instance, and object storage at fractions of a cent per GB. Total for a hobby-scale
fleet: well under $15/month — the same job on a managed scraping API would run
$50-200/month.

## Wrap-up

A headless-browser scraper on Vultr is: one Dockerfile, one Python file, two instances,
and a bucket. It handles JavaScript-rendered sites, stores results durably, and scales
by adding workers. When your target site changes, you fix the parser — not the
infrastructure.

*Have you run scrapers on Vultr? Share your setup in the comments.*
