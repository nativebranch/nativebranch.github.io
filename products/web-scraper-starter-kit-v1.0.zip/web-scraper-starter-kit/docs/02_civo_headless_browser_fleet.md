# Scraping at scale: a headless-browser fleet on Civo Kubernetes

*Hands-on guide for the Civo community — build a horizontally-scalable web scraping platform on Civo's managed K3s in an afternoon.*

## Why a browser fleet?

Modern sites render content in JavaScript. Plain HTTP clients get empty shells; a
headless browser gets the real page. The moment your scraping workload needs more than
one page at a time — price monitoring, competitor catalogs, LLM training corpora, SEO
audits — you stop wanting "a scraper" and start wanting **a fleet**: many browser
workers, a shared queue, and a way to scale up at 9am and down at midnight.

That's exactly what Kubernetes is good at, and Civo's managed K3s makes the operational
part almost invisible: no control plane to babysit, fast node pools, and a
single-command `kubeconfig` download. This guide builds the whole platform with
standard manifests — nothing proprietary, everything portable.

## Architecture

```
             ┌──────────────┐   jobs    ┌──────────────────┐
  scheduler ─►   queue      ───────────►  browser workers   │
  (CronJob)    (Redis)      ◄──────────  (Deployment/HPA)   │
             └──────────────┘  results  └──────────────────┘
                                             │
                                        object storage
                                        (results JSONL)
```

- **Queue:** Redis (Civo has one-click managed Redis) holds the URL list.
- **Workers:** stateless Pods that pop a URL, render it in a headless browser, and push
  the result to object storage.
- **Scheduler:** a CronJob enqueues URLs on your cadence.
- **Autoscaler:** HPA scales workers on queue depth.

Because workers are stateless, scaling is boring — which is the point.

## Step 1 — The worker image

Use the official Playwright image so browser binaries are already installed, then add a
tiny worker script. The key design decision: **the worker never stores state** — it
reads a job from Redis and writes a file to object storage.

```dockerfile
FROM mcr.microsoft.com/playwright/python:v1.49.0-noble

WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY worker.py .
CMD ["python", "worker.py"]
```

```python
# worker.py — pop a URL, render it, store the result
import json, redis, uuid, boto3
from playwright.sync_api import sync_playwright

r = redis.Redis(host="redis", port=6379, decode_responses=True)
s3 = boto3.client("s3", endpoint_url="https://objectstore...", ...)  # Civo Object Store

while True:
    url = r.blpop("scrape:queue", timeout=5)
    if not url:
        continue
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        page = browser.new_page()
        page.goto(url, timeout=30000, wait_until="networkidle")
        html = page.content()
        browser.close()
    key = f"pages/{uuid.uuid4().hex}.html"
    s3.put_object(Bucket="scraped", Key=key, Body=html)
    r.rpush("scrape:done", json.dumps({"url": url, "key": key}))
```

## Step 2 — Deploy on Civo

Provision a cluster, grab the config, and apply:

```bash
civo kubernetes create scraper-fleet --size=g4s.kube.xsmall --nodes=3 --wait
civo kubernetes config scraper-fleet --save
kubectl apply -f manifests/
```

The manifests are three files. Workers with an HPA that watches a custom metric:

```yaml
# manifests/worker.yaml
apiVersion: apps/v1
kind: Deployment
metadata: { name: browser-workers }
spec:
  replicas: 2
  selector: { matchLabels: { app: browser-worker } }
  template:
    metadata: { labels: { app: browser-worker } }
    spec:
      containers:
        - name: worker
          image: your-registry/scraper-worker:latest
          resources:
            requests: { cpu: 500m, memory: 1Gi }
            limits:   { cpu: "2",    memory: 2Gi }
```

The queue-length autoscaler (using the Redis exporter + Prometheus adapter — or keep it
simple with CPU-based HPA and a `minReplicas`/`maxReplicas` range):

```yaml
# manifests/hpa.yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata: { name: browser-workers }
spec:
  scaleTargetRef: { apiVersion: apps/v1, kind: Deployment, name: browser-workers }
  minReplicas: 2
  maxReplicas: 20
  metrics:
    - type: External
      external:
        metric: { name: redis_queue_depth }
        target: { type: AverageValue, averageValue: "50" }
```

And the scheduler CronJob:

```yaml
# manifests/scheduler.yaml
apiVersion: batch/v1
kind: CronJob
metadata: { name: enqueue-urls }
spec:
  schedule: "*/30 * * * *"
  jobTemplate:
    spec:
      template:
        spec:
          restartPolicy: OnFailure
          containers:
            - name: enqueue
              image: your-registry/enqueue:latest
              env: [{ name: REDIS_URL, value: "redis://redis:6379" }]
```

## Step 3 — Scale it like you mean it

Three levers, in order of preference:

1. **Queue depth (correct).** Scale on the number of pending URLs. The Redis external
   metric above does exactly this; workers spin up only when there's work.
2. **CPU (good enough).** Browsers are CPU-hungry during page load and mostly idle
   afterwards, so CPU-based HPA tends to lag. Fine for steady loads.
3. **Time-of-day (predictable).** If your crawl window is "Europe business hours", a
   CronJob that patches `replicas` at 8:00 and 18:00 is simpler than any metric and
   costs nothing to operate.

One honest warning: **headless browsers are memory pigs.** A Chromium tab comfortably
uses 300–600 MB. Budget 1–2 GiB per replica, cap concurrency per Pod (`MAX_CONCURRENCY=2`
in the worker — one browser per tab, two tabs per Pod), and you'll avoid the classic
OOMKilled cascade where the HPA scales up and every new Pod dies at once.

## Step 4 — Results, not just pages

Raw HTML in object storage is a start. For anything analytical, point a data pipeline
at the `scrape:done` queue: parse to JSONL, load into Postgres (Civo has one-click
managed Postgres too), and schedule refreshes. The browser fleet's job ends where the
data platform's begins — and the files in object storage make the handoff trivial.

## Wrap-up

A scraping platform is a queue, a stateless worker, a scheduler, and an autoscaler.
On Civo's managed K3s that's three small manifests and one Dockerfile — no control-plane
ops, no cluster babysitting, and a fleet that scales with your queue instead of your
anxiety. Start with 2 replicas and a CronJob; when the queue starts backing up, add the
HPA and watch the fleet do the rest.

*What's your scraping fleet look like — Playwright, Puppeteer, or something lighter?
Tell us in the comments.*
