# From websites to warehouse: an ELT pipeline for scraped data with Airbyte

*Tutorial — for the Airbyte community blog. Verified end-to-end with Airbyte OSS 1.x patterns, a real headless-browser scrape, and DuckDB as the landing zone.*

## The problem with hand-rolled scrapers

Most scraping projects start the same way: a script, a `while` loop, and a CSV file that
nobody trusts. It works for a week. Then the target site changes its markup, the script
silently produces empty rows, and the downstream dashboard starts showing "no data" with
no error anywhere. When you finally get the data into a database, there is no schema
enforcement, no incremental sync, and no way to answer the question *"what changed
between Tuesday and Wednesday?"*

The fix is not a better scraper. The fix is to treat scraping as **the source half of an
ELT pipeline** and let a real data-movement platform own extraction, normalization,
scheduling, and delivery.

In this tutorial you'll build a small but production-shaped pipeline:

```
target site ──► headless browser ──► JSONL files ──► Airbyte (file source)
                                                       │
                                                       ├──► DuckDB / Postgres (analytics)
                                                       └──► vector store (RAG)
```

Everything is open source, runs on a laptop, and the same pattern scales to a fleet of
scrapers and terabytes of data.

## Step 1 — Scrape with a headless browser, not `requests`

The classic mistake is scraping with plain HTTP and regex. Modern sites render content
with JavaScript, so you get back an empty shell. A headless browser executes the page
like a real browser and gives you the rendered DOM.

I used a lightweight headless browser CLI (Chromium-compatible, no server required —
think of it as `curl` for rendered pages) to fetch the Hacker News front page:

```bash
obscura fetch --dump html "https://news.ycombinator.com/" > hn_raw.html
```

Why a browser at all for a site that *does* server-render? Because the same command works
unchanged for SPAs, login-walled dashboards, and paginated app views — and it gives you a
realistic user-agent and JS execution, which many sites require.

## Step 2 — Normalize to JSONL at the edge

The scrape produces HTML; the pipeline needs records. Keep this step tiny and idempotent:
parse the DOM, emit one JSON object per line, add metadata (source URL, scrape time).

```python
from bs4 import BeautifulSoup
import json, datetime

html = open("hn_raw.html").read()
soup = BeautifulSoup(html, "lxml")
records = []
for tr in soup.select("tr.athing"):
    a = tr.select_one("td.title span.titleline a")
    if not a:
        continue
    records.append({
        "rank": tr.select_one("span.rank").get_text(strip=True).rstrip("."),
        "title": a.get_text(strip=True),
        "url": a.get("href"),
        "site": (tr.select_one("span.sitestr").get_text(strip=True)
                 if tr.select_one("span.sitestr") else None),
        "scraped_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "source": "news.ycombinator.com",
    })

with open("hn_items.jsonl", "w") as f:
    for r in records:
        f.write(json.dumps(r) + "\n")
```

Run it once and verify the output before wiring anything else up:

```bash
wc -l hn_items.jsonl        # 30 items on a normal front page
head -1 hn_items.jsonl | jq  # pretty-print one record
```

**Why JSONL and not CSV?** Schemas drift. A JSON object per line survives new fields,
nested structures, and nulls far better than CSV, and Airbyte's file-based source
handles it natively.

## Step 3 — Land it with Airbyte

Now the data stops living in a folder and starts living in your warehouse. With Airbyte
OSS installed (`docker compose up` from the official quickstart), create a connection:

1. **Source: File (JSONL).** Point it at the directory where your scraper writes files
   (or an S3/GCS bucket — the connector supports URL, S3, GCS, Azure, and local paths).
   Set the dataset name, and enable **incremental sync** with `scraped_at` as the cursor
   field. From then on, Airbyte only moves files that changed.
2. **Destination: DuckDB or Postgres.** DuckDB is a great local landing zone: zero
   servers, columnar, and it reads the JSONL with schema inference on the fly. In
   production, swap in Postgres or Snowflake/BigQuery and nothing else changes.
3. **Normalization on.** Airbyte's basic normalization turns the raw stream into a
   typed, queryable table (`hn_items`) with a stable primary key.

The resulting table is immediately useful:

```sql
SELECT site, count(*) AS stories
FROM hn_items
GROUP BY site
ORDER BY stories DESC;
```

## Step 4 — Schedule and observe

The scraper writes files on its own schedule (cron, CI, or a Kubernetes CronJob — the
browser step is stateless, so it scales horizontally). Airbyte's **scheduled sync** then
runs the extraction at whatever cadence you need — every 15 minutes for a price tracker,
nightly for a news corpus.

Two operational habits that save real pain:

- **Give every record a stable cursor.** Your `scraped_at` timestamp is also your
  incremental key. Without it you re-sync everything and pay the dedupe tax forever.
- **Watch connector health, not just pipeline logs.** Airbyte surfaces sync failures,
  schema changes, and row counts per sync — that's your early-warning system when the
  target site changes its DOM (your scraper produces zero rows, and the sync metrics
  drop before anyone's dashboard breaks).

## Step 5 — Make it RAG-ready

The same records that feed your analytics tables can feed your vector database. Add a
second destination (Pinecone, Qdrant, Weaviate, or pgvector) to the same source, chunk
each record's text field in the normalization step, and you have an embedding pipeline
that stays fresh on the same schedule as your warehouse — no bespoke glue code.

## Gotchas we've hit in production

1. **Schema drift is the rule.** New fields appear; old ones disappear. JSONL absorbs
   this; strict CSVs break the sync. Let Airbyte's auto-detection handle it and diff the
   resulting table when something looks off.
2. **Respect the target.** Run scrapes at a polite rate, cache aggressively, and keep an
   eye on your user-agent. A headless browser is not a license to hammer.
3. **Separate scrape from load.** If the browser crashes, you want a retryable file
   write, not a half-written database row. Files are the buffer that makes both sides
   independently retryable.
4. **Test the empty case.** Sites go down. Make sure a zero-record scrape produces a
   valid (possibly empty) JSONL file, and that your sync handles it without erroring.

## Wrap-up

The whole pipeline — headless-browser scrape, JSONL normalization, Airbyte sync to
DuckDB/Postgres, optional vector destination — is about 60 lines of code plus one
Airbyte connection, and it replaces the hand-rolled script-and-CSV pattern with
something that has real scheduling, incremental sync, schema handling, and
observability. When the target site changes, you fix the parser, not the pipeline.

*Have you run scraped data through Airbyte? What's your normalization setup — raw JSONL,
dbt on top, or something else? The comments are open.*
