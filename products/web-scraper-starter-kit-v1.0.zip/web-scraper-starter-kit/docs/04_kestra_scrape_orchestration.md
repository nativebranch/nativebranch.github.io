# Orchestrating scraped-data pipelines with Kestra: schedules, retries, and backfills that don't lie

*Tutorial for the Kestra community blog — a runnable blueprint for web-data pipelines,
with the operational gotchas that only show up after week two.*

## The problem: scrapers work until they don't

A scraping pipeline looks simple: fetch page, parse, store. Then the target site changes
its markup at 3am, your parser silently returns zero rows, and the dashboard shows
"no data" with no error anywhere. What's missing is not a better parser — it's an
**orchestrator** that owns scheduling, retries, backfills, and observability so that
when something breaks, the pipeline tells you *what* broke and *when*.

Kestra is a good fit here because flows are declarative YAML, every task is retryable,
and the built-in scheduler + backfill commands cover exactly the operational surface a
scraping pipeline needs.

## The blueprint

```
┌────────────────────────────────────────────────────┐
│ scrape_flow (every 30 min)                          │
│  1. trigger: schedule cron */30                     │
│  2. task: fetch page (headless browser or HTTP)     │
│  3. task: parse HTML → JSONL (Python script)        │
│  4. task: load JSONL → Postgres (or DuckDB)         │
│  5. task: check row count > 0, else fail loudly     │
│  6. task: notify Slack on failure                   │
└────────────────────────────────────────────────────┘
```

## A minimal flow that works

```yaml
id: scrape_hackernews
namespace: data.scraping
description: Scrape HN front page, parse to JSONL, load to Postgres.

tasks:
  - id: fetch_page
    type: io.kestra.plugin.scripts.shell.Commands
    taskRunner:
      type: io.kestra.plugin.scripts.runner.docker.Docker
    containerImage: mcr.microsoft.com/playwright/python:v1.49.0-noble
    commands:
      - python fetch.py https://news.ycombinator.com/ > /tmp/hn_raw.html

  - id: parse_to_jsonl
    type: io.kestra.plugin.scripts.python.Script
    taskRunner:
      type: io.kestra.plugin.scripts.runner.docker.Docker
    containerImage: python:3.12-slim
    script: |
      from bs4 import BeautifulSoup
      import json, datetime
      html = open("/tmp/hn_raw.html").read()
      soup = BeautifulSoup(html, "lxml")
      records = []
      for tr in soup.select("tr.athing"):
          a = tr.select_one("td.title span.titleline a")
          if not a:
              continue
          records.append({
              "title": a.get_text(strip=True),
              "url": a.get("href"),
              "scraped_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
          })
      with open("/tmp/hn_items.jsonl", "w") as f:
          for r in records:
              f.write(json.dumps(r) + "\n")
      print(f"parsed {len(records)} records")

  - id: load_to_postgres
    type: io.kestra.plugin.jdbc.postgresql.Copy
    url: jdbc:postgresql://host.docker.internal:5432/warehouse
    username: "{{ secret('PG_USER') }}"
    password: "{{ secret('PG_PASS') }}"
    table: hn_items
    from: /tmp/hn_items.jsonl
    format: JSONL

  - id: assert_nonempty
    type: io.kestra.plugin.scripts.shell.Commands
    taskRunner:
      type: io.kestra.plugin.scripts.runner.docker.Docker
    containerImage: alpine:3.20
    commands:
      - test -s /tmp/hn_items.jsonl

triggers:
  - id: schedule
    type: io.kestra.plugin.core.trigger.Schedule
    cron: "*/30 * * * *"
```

The `assert_nonempty` task is the most important line in this file: an empty scrape is
the failure mode that *doesn't* error on its own, so we make it error explicitly.

## Retries that don't make things worse

Target sites are flaky; retries are mandatory. Two rules:

1. **Retry the fetch, not the load.** Downloads fail for transient reasons (timeouts,
   rate limits, 5xx). Loads fail for data reasons (schema drift) — retrying those just
   multiplies the error. Put `retry: { type: constant, interval: PT1M, maxAttempt: 5 }`
   on the fetch task only.
2. **Idempotency keys in the data.** Give every record a stable key (`url + scraped_at`
   is a good start). If a backfill re-runs a window, upsert on that key instead of
   appending, and duplicates stop being a thing.

## Backfills when the parser changes

You fixed the parser — now the last three days of data are wrong. Kestra's backfill
handles this cleanly:

```bash
kestra flow backfill --namespace data.scraping --id scrape_hackernews \
  --start "2026-08-01T00:00:00" --end "2026-08-08T00:00:00"
```

The flow re-runs for every schedule tick in the window, and because the load task
upserts on the idempotency key, re-running old windows is safe.

## Observability: the pipeline should tell you when it's lying

- **Row counts per run.** Log `parsed N records` (as above) and alert when N drops by
  more than X% versus the trailing average — the classic "site changed its DOM" signal.
- **Execution state.** Kestra's UI shows every execution, its tasks, and logs; point
  your team at the flow page instead of "check the cron".
- **Failure notifications.** A `io.kestra.plugin.notifications.slack.SlackIncomingWebhook`
  task on the error branch (`errors:` block) turns 3am breakage into a message you see
  at 3:01am.

## Wrap-up

A scraping pipeline is 90% boring operations: scheduling, retries, backfills, and
knowing when the data is wrong. Kestra's declarative flows, per-task retry, backfill
command, and execution UI cover all four — so the remaining 10% (the parser itself)
is the only part you actually have to think about.

*What's your scraper orchestration setup? Share your flow patterns in the comments.*
